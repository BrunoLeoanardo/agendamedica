/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ufrpe.prog2.sistemaconsulta1.negocio;

/**
 *
 * @author nini
 */
public class  Medico extends Usuario {
    public static Object imprimirMedicos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private String nome;
    private String especialidade;

    public Medico(String nome, String cpf, String especialidade, String email) {
        super(nome, cpf, email);
        this.especialidade = especialidade;
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }
    @Override
    public void fazerLogin(){
        System.out.println("login Medico executado com sucesso!");
    }
    
    public String getCpfmedico(){
        return getCpf();
    }
    public String getEmailmedico(){
        return getEmail();
    }
    

}
