/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ufrpe.prog2.sistemaconsulta1.dados;

import java.util.ArrayList;
import ufrpe.prog2.sistemaconsulta1.negocio.Medico;
import ufrpe.prog2.sistemaconsulta1.negocio.Paciente;

/**
 *
 * @author nini
 */
public class BancoDeDados {
    public static ArrayList<Medico> medicos = new ArrayList<>();
    public static ArrayList<Paciente> pacientes = new ArrayList<>();
}
